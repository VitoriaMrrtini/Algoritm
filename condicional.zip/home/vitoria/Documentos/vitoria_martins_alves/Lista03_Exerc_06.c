#include <stdio.h>

int main()
{
    float valor;
    
    printf("Digite seu valor da compra: ");
    scanf("%f", &valor);

    if (valor < 10.0)
    {
        printf("Preço de venda %f\n", valor * 1.7);
    }
    else if (valor >= 10 && valor < 30.0)
    {
        printf("Preço de venda %f\n", valor * 1.5);
    }
    else if (valor >= 30 && valor < 50.0)
    {
        printf("Preço de venda %f\n", valor * 1.4);
    }
    else
    {
        printf("Preço de venda %f\n", valor * 1.3);
    }

    return 0;
}