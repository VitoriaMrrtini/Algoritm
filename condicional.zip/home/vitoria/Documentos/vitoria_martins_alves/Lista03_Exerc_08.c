#include <stdio.h>

int main()
{

    float altura;
    char genero;

    printf("Qual o seu genero? F/M ");
    scanf("%c", &genero);
    printf("Digite sua altura: ");
    scanf("%f", &altura);

    if (genero == 'F' || genero == 'f')
    {
        printf("Seu peso ideal é: %.2f", (62.1 * altura) - 44.7);
    }
    else if (genero == 'M' || genero == 'm')
    {
        printf("Seu peso ideal é: %.2f", (72.7 * altura) - 58.0);
    }
    else
    {
        printf("Caractere inválido");
    }

    return 0;
}