#include <stdio.h>

int main()
{
    int numero, soma = 0, digito;

    printf("Digite um número maior que 0 e melhor que 999:\n");
    scanf("%d", &numero);

    if (numero >= 0 && numero <= 999)
    {
        if (numero >= 0)
        {
            digito = numero % 10;
            soma = soma + digito;
            numero = numero / 10;

            if (numero > 0)
            {
                digito = numero % 10;
                soma = soma + digito;
                numero = numero / 10;

                if (numero > 0)
                {
                    digito = numero % 10;
                    soma = soma + digito;
                    numero = numero / 10;
                }
            }
        }
    }
    printf("A soma dos digitos e: %d\n", soma);
    return 0;
}