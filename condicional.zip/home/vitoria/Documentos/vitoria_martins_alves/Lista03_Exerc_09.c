#include <stdio.h>

int main()
{

    int idade_um, idade_dois, idade_tres, maior, menor;

    printf("Digite a primeira idade: ");
    scanf("%d", &idade_um);
    printf("Digite a segunda idade: ");
    scanf("%d", &idade_dois);
    printf("Digite a terceira idade: ");
    scanf("%d", &idade_tres);

    if (idade_um > idade_dois && idade_um > idade_tres)
    {
        maior = idade_um;
    }
    else if (idade_dois > idade_um && idade_dois > idade_tres)
    {
        maior = idade_dois;
    }
    else
    {
        maior = idade_tres;
    }

    if (idade_um < idade_dois && idade_um < idade_tres)
    {
        menor = idade_um;
    }
    else if (idade_dois < idade_um && idade_dois < idade_tres)
    {
        menor = idade_dois;
    }
    else
    {
        menor = idade_tres;
    }

    printf("O maior número é %d\n", maior);
    printf("O menor número é %d\n", menor);

    return 0;
}