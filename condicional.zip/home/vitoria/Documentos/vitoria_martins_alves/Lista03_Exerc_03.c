#include <stdio.h>

int main()
{
    float salario, valor_emprestino;
    
    printf("Digite seu salario: ");
    scanf("%f", &salario);
    printf("Digite o valor do emprestino: ");
    scanf("%f", &valor_emprestino);

    if (valor_emprestino <= (salario * 0.2))
    {
        printf("Emprestimo concedido!\n");
    }
    else
    {
        printf("Emprestimo negado!\n");
    }

    return 0;
}