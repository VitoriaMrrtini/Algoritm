#include <stdio.h>

int main()
{
    int numero;
    
    printf("Digite seu numero: ");
    scanf("%d", &numero);

    if (numero % 3 == 0 && numero & 5 == 0)
    {
        printf("É divisível por ambos\n");
    }
    else
    {
        printf("Não é divisível por ambos\n");
    }

    return 0;
}