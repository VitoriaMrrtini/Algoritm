#include <stdio.h>

int main() {


    char jogador_um, jogador_dois;

    printf("Jogador 1 (P/A/T): ");
    scanf("%c", &jogador_um);
    printf("Jogador 2 (P/A/T): ");
    scanf("%c", &jogador_dois);
    
    if (jogador_um == jogador_dois)
    {
        printf("Empate");
    }
    else if (jogador_dois == 'A' && jogador_um == 'P')
    {
        printf("Jogador 2 venceu, Papel ganha de pedra\n");
    }
    else if (jogador_dois == 'P' && jogador_um == 'T')
    {
        printf("Jogador 2 venceu, Pedra ganha de tesoura\n");
    }
    else if (jogador_dois == 'T' && jogador_um == 'A')
    {
        printf("Jogador 2 venceu, Tesoura ganha de papel\n");
    }
    else if (jogador_um == 'A' && jogador_dois == 'P')
    {
        printf("Jogador 1 venceu, Papel ganha de pedra\n");
    }
    else if (jogador_um == 'P' && jogador_dois == 'T')
    {
        printf("Jogador 1 venceu, Pedra ganha de tesoura\n");
    }
    else if (jogador_um == 'T' && jogador_dois == 'A')
    {
        printf("Jogador 1 venceu, Tesoura ganha de papel\n");
    }
    else
    {
        printf("Entrada inválida");
    }
    
    

    return 0;
}