#include <stdio.h>

int main()
{
    int ano;
    
    printf("Digite um ano: ");
    scanf("%d", &ano);

    if ((ano % 400 == 0) || ((ano % 4 == 0) && (ano % 400 != 0)))
    {
        printf("É um ano bissexto!\n");
    }
    else
    {
        printf("Não é um ano bissexto!\n");
    }

    return 0;
}