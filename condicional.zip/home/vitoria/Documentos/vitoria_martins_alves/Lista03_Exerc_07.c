#include <stdio.h>

int main()
{

    float nota_um, nota_dois;
    int aulas_totais, faltas;
    
    printf("Digite sua primeira nota: ");
    scanf("%f", &nota_um);
    printf("Digite sua segunda nota: ");
    scanf("%f", &nota_dois);
    printf("Digite o numeros de aulas do semestre: ");
    scanf("%d", &aulas_totais);
    printf("Digite seu numero de faltas: ");
    scanf("%d", &faltas);

    if (((nota_um + nota_dois) / 2) >= 6.0)
    {
        if ((faltas / aulas_totais) > 0.75)
        {
            printf("Aprovado!\n");
        }
        else
        {
            printf("Reprovado!\n");
        }
    }
    else
    {
        printf("Reprovado!\n");
    }

    return 0;
}