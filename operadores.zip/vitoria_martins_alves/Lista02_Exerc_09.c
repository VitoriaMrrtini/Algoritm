#include <stdio.h>
#include <locale.h>
#include <stdbool.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    bool x;
    x = !(-5);

    printf("%s\n", x ? "true" : "false");

    return 0;
}