#include <stdio.h>
#include <locale.h>
#include <math.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int a, b, c;
    float ma, mg, mh;
    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);

    ma = (a + b + c) / 3;
    mg = pow(a*b*c ,1/3);
    mh = 3 / ((1/a) + (1/b) + (1/c));
    printf("%f, %f, %f", ma, mg, mh);
    return 0;
}