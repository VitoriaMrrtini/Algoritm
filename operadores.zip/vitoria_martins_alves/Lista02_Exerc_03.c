#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int a = 10;
    int b = 20;
    a+=1;
    b-=1;
    int c = a + b;
    printf("%d\n%d\n%d\n", a, b, c);

    return 0;
}