#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    float x = (-5 || 0) || (3 >= 2) && (1 != 0);
    printf("%f", x);
    return 0;
}