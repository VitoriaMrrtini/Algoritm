#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int x, y, z;
    scanf("%d", &x);
    scanf("%d", &y);
    scanf("%d", &z);

    int media = (x + y + z) / 3;
    int max_xy = (x + y + abs(x - y)) / 2;
    int maior = (max_xy + z + abs(max_xy - z)) / 2;
    int min_xy = (x + y - abs(x - y)) / 2;
    int menor = (min_xy + z - abs(min_xy - z)) / 2;

    printf("Média: %2d\n", media);
    printf("Maior: %2d\n", maior);
    printf("Menor: %2d\n", menor);

    return 0;
}