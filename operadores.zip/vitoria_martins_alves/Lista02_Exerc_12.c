#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    int x, y, z, soma;
    scanf("%d", &x);
    scanf("%d", &y);
    scanf("%d", &z);

    soma = x*x + y*y + z*z;
    printf("%d\n", soma);

    return 0;
}