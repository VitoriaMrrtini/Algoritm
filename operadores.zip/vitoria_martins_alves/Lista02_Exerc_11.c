#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    float real, dolar;
    printf("Digite o valor em real: ");
    scanf("%f", &real);
    dolar = real * 5.1;
    printf("%f\n", dolar);

    return 0;
}