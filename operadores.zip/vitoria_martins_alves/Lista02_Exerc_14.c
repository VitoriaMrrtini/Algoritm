#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    float h, base_maior, base_menor, area_trapezio;
    printf("Digite a base maior");
    scanf("%f", &base_maior);
    printf("Digite a base menor");
    scanf("%f", &base_menor);
    printf("Digite a altura");
    scanf("%f", &h);
    area_trapezio = (h * (base_maior + base_menor)) / 2;

    return 0;
}