#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int horas, minutos, segundos;
    scanf("%d", &segundos);
    horas = segundos / 3600;
    minutos = minutos % 3600;
    segundos -= (horas * 3600 + minutos * 60);

    printf("%02d:%02d:%02dh", horas, minutos, segundos);
    return 0;
}