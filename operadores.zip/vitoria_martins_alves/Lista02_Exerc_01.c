#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int x, y, z;
    z = 0;
    printf("%d\n", z);
    x = y = 10;
    printf("%d\n", x);
    printf("%d\n", y);
    z += 1;
    printf("%d\n", z);
    x = -x;
    printf("%d\n", x);
    y += 1;
    printf("%d\n", y);
    x = x + y - (z - 1);
    printf("%d\n", x);

    return 0;
}