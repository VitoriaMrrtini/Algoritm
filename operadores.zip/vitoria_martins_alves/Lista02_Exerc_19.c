#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int num;
    printf("Informe o número: ");
    scanf("%d", &num);
    printf("%d x 1 = %d\n"
        "%d x 2 = %2d\n"
        "%d x 3 = %2d\n"
        "%d x 4 = %2d\n"
        "%d x 5 = %2d\n"
        "%d x 6 = %2d\n"
        "%d x 7 = %2d\n"
        "%d x 8 = %2d\n"
        "%d x 9 = %2d\n"
        "%d x 10 = %2d\n",
        num, (num*1),
        num, (num*2),
        num, (num*3),
        num, (num*4),
        num, (num*5),
        num, (num*6),
        num, (num*7),
        num, (num*8),
        num, (num*9),
        num, (num*10));

    return 0;
}