

#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int a = 1, b = 2, c = 3,  x = 4, y = 5;
    a == 'A'; //Falso
    a > b; //Falso
    a =< b; //Verdadeiro
    a >= b; //Falso
    -a = b; //Erro
    -a = = b; // Erro
    a =! b; //Erro
    -85.2 >= (x * 45.3 + 32.34); // Verdadeiro
    -a == b; //Falso
    a + b + c == -x * -y; //Falso
    'a' + 'b' != 16 + 'w'; // 97 + 98 diferente de 16 + 119, Verdadeiro

    return 0;
}