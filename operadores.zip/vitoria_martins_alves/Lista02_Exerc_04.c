#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int v = 0, x = 1, y = 2, z = 3;
    v += x+y;
    x *= y = z + 1;
    z %= v + v + v;
    v += x += y += 2;
    printf("%d\n%d\n%d\n%d\n", v, x, y, z);

    return 0;
}