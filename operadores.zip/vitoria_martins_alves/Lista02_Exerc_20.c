#include <stdio.h>
#include <locale.h>
#include <math.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int dias, anos, semanas;
    printf("Dias: ");
    scanf("%d", &dias);
    anos = dias / 365;
    semanas = (dias - (anos * 365)) / 7;
    dias = dias - ((anos * 365) + (semanas * 7));
    printf("%d ano(s), %d semana(s) e %d dia(s)", anos, semanas, dias);

    return 0;
}