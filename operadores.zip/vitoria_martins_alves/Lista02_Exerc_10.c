#include <stdio.h>
#include <locale.h>
#include <stdbool.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    int i = 1, j = 2, k = 3, n = 2;
    float x = 3.3, y = 4.4;

    bool m = i < j + 3;
    bool v = 2 * i - 7 <= j - 8;
    bool c = -x + y >= 2.0 * y;
    bool b = i + j + k == -2 * -k;
    bool p = i && j && k;
    bool w = i || j - 3 && 0;
    bool s = i < j && 2 >= k;
    bool l = i < j || 2 >= k;
    bool o = i == 2 || j == 4 || k == 5;


    printf("%s\n", m ? "true" : "false");
    printf("%s\n", v ? "true" : "false");
    printf("%s\n", c ? "true" : "false");
    printf("%s\n", b ? "true" : "false");
    printf("%s\n", p ? "true" : "false");
    printf("%s\n", w ? "true" : "false");
    printf("%s\n", s ? "true" : "false");
    printf("%s\n", l ? "true" : "false");
    printf("%s\n", o ? "true" : "false");


    return 0;
}