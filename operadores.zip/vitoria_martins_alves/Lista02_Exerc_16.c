#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    float f, c;
    printf("Digite em um valor em Celsius: ");
    scanf("%f", &c);
    f = c * (9.0 / 5.0) + 32.0;
    printf("%.2f\n", f);
    return 0;
}