#include <stdio.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");
    float v, r, h;
    printf("Digite o raio: ");
    scanf("%f", &r);
    printf("Digite o altura: ");
    scanf("%f", &h);

    v = 3.12159 * (r*r) * h;
    printf("%.2f", v);

    return 0;
}