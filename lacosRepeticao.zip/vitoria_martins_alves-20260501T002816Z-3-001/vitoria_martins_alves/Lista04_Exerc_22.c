#include <stdio.h>
#define TAXA_A 25 / 10
#define TAXA_B 18 / 10

int main()
{
    double habitantes_A = 30000, habitantes_B = 100000;

    while (habitantes_B >= habitantes_A)
    {
        habitantes_A *= (1 + TAXA_A);
        habitantes_B *= (1 + TAXA_B);
    }

    printf("Habitantes A: %.2f\nHabitantes B: %.2f\n", habitantes_A, habitantes_B);
    
    return 0;
}