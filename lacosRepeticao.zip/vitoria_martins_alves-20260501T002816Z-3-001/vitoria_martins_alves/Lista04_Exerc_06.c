#include <stdio.h>

int main()
{
    int valor;
    printf("Digite um número: ");
    scanf("%d", &valor);

    for (int i = 1; i < 100; i++)
    {
        if (valor % i == 0)
        {
            printf("Multiplo de %d: %d\n", valor, i);
        }
        
    }
    
    

    return 0;
}