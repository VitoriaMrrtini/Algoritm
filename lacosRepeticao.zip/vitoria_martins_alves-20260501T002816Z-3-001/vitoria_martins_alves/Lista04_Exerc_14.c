#include <stdio.h>

int main()
{
    int numero, j;

    printf("Digite um número: ");
    scanf("%d", &numero);

    for (int i = 2; i <= numero; i++)
    {
        int x = 0;

        for (j = 1; j <= i; j++)
        {
            if (i % j == 0)
            {
                x++;
            }
        }

        if (x == 2)
        {
            printf("%d\n", i);
        }
    }

    return 0;
}