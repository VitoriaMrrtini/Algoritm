#include <stdio.h>

int main()
{
    int n1, n2, n3, sum = 0;

    printf("Digite um valor inicial: ");
    scanf("%d", &n1);
    printf("Digite um valor da progressão: ");
    scanf("%d", &n2);
    printf("Digite um valor de parada: ");
    scanf("%d", &n3);

    int atual = n1;

    if (n2 > 0) 
    {
        while (atual <= n3)
        {
            printf("%d ", atual);
            atual += n2;
        }   
    }
    else
    {
        while (atual >= n3)
        {
            printf("%d ", atual);
            atual += n2;
        }   
    }

    return 0;
}