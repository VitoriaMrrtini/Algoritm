#include <stdio.h>

int main()
{
    int valor, n1, n2;

    printf("Digite um valor: ");
    scanf("%d", &valor);
    printf("Digite o valor inicial: ");
    scanf("%d", &n1);
    printf("Digite o valor final: ");
    scanf("%d", &n2);

    for (int i = n1; i <= n2; i++)
    {
        if (i % valor == 0)
        {
            printf("Múltiplo de %d: %d\n", valor, i);
        }
    }

    return 0;
}