#include <stdio.h>
#include <stdbool.h>

int main()
{
    int numero, sum = 0;

    while (true)
    {
        printf("Digite um número: ");
        scanf("%d", &numero);
        if (numero == -1)
        {
            continue;
        }
        else if (numero == -999)
        {
            break;
        }
        else
        {
            sum += numero;
        }
    }

    printf("%d\n", sum);

    return 0;
}