#include <stdio.h>

int main()
{
    int n1, n2, sum = 0;

    printf("Digite um número e a sua multiplicação: ");
    scanf("%d", &n1);
    scanf("%d", &n2);

    for (int i = 0; i < n2; i++)
    {
        sum += n1;
    }

    printf("Multiplicação: %d\n", sum);
    return 0;
}