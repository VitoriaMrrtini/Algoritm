#include <stdio.h>

int main()
{
    int n1, n2, menor, maior, sum_par = 0, sum_impar = 0;
    
    printf("Digite dois valores: ");
    scanf("%d", &n1);
    scanf("%d", &n2);

    if (n1>n2)
    {
        maior = n1;
        menor = n2;
    } else
    {
        maior = n2;
        menor = n1;
    }

    for (; menor <= maior; menor++)
    {
        if (menor % 2 == 0)
        {
            sum_par += menor;
        } else
        {
            sum_impar += menor;
        }
        
    }

    printf("Soma par: %d\n", sum_par);
    printf("Soma impar: %d\n", sum_impar);
    

    return 0;
}