#include <stdio.h>

int main()
{
    int numero, sum = 0;
    printf("Digite um valor: ");
    scanf("%d", &numero);

    for (int i = 1; i < numero; i++)
    {
        if (numero % i == 0)
        {
            sum += i;
        }
    }

    printf("%d\n", sum);

    return 0;
}