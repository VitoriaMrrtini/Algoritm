#include <stdio.h>

int main()
{
    int numero, sum = 0;
    printf("Digite um valor: ");
    scanf("%d", &numero);

    for (int i = 1; i < numero; i++)
    {
        if (numero % i == 0)
            sum += i;
    }

    if (sum == numero)
        printf("É um número perfeito\n");
    else
        printf("Não é um número perfeito\n");

    return 0;
}