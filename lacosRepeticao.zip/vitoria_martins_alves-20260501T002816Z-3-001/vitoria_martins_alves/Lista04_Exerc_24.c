#include <stdio.h>

int main()
{
    int meses = 0;
    float juros_mensais, divida_inicial, divida_final;
    printf("Digite a dívida inical: ");
    scanf("%f", &divida_inicial);
    printf("Digite os juros: ");
    scanf("%f", &juros_mensais);

    divida_final = divida_inicial;

    while (divida_final < divida_inicial*2)
    {
        divida_final *= (1 + juros_mensais);
        meses++;
    }
    
    printf("A dívida dobrara em %d meses", meses);


    return 0;
}