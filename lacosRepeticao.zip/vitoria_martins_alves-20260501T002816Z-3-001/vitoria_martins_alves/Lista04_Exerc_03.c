#include <stdio.h>
#define MAX 5

int main()
{
    int num, maior = -999999, menor = 999999;
    int cont_par = 0, cont_impar = 0, soma_par = 0, soma_impar = 0;

    for (int i = 0; i < MAX; i++)
    {
        printf("Digite um valor: ");
        scanf("%d", &num);

        if(num > maior)
            maior = num;

        if(num < menor)
            menor = num;
        

        if(num % 2 == 0)
        {
            cont_par++;
            soma_par += num;
        }
        else
        {
            cont_impar++;
            soma_impar += num;
        }
    }

    printf("Maior valor: %d\n", maior);
        printf("Menor valor: %d\n", menor);
        printf("Média pares: %.2f\n", (float)soma_par/cont_par);
        printf("Média í mpar: %.2f\n", (float)soma_impar/cont_impar);
    
}