#include <stdio.h>

int main()
{
    float altura_chico = 1.50;
    float crescimento = 0.02;
    float altura_ze = 1.10;
    int anos = 0;

    while (altura_chico > altura_ze)
    {
        altura_chico += crescimento;
        anos++;
    }

    printf("Será necessário %d anos para que Zé seja maior que Chico\n", anos);

    return 0;
}