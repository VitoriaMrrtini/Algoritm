#include <stdio.h>

int main()
{
    int valor, sum = 0, j = 0;

    printf("Digite um valor: ");


    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &valor);
        if (valor > 0)
        {
            sum += valor;
        } else
        {
            j++;
        }
    }

    printf("A soma dos valores positivos é %d\n", sum);
    printf("O total dos valores negativos é %d\n", j);
    

    return 0;
}