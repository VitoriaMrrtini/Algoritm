#include <stdio.h>

int main()
{
    int numero;
    float fatorial, E = 0.0;
    printf("Digite um valor: ");
    scanf("%d", &numero);

    for (int i = 0; i <= numero; i++)
    {
        fatorial = 1.0;

        for (int j = 1; j <= i; j++)
            fatorial *= j;

        E += 1.0 / fatorial;
    }

    printf("%.2f\n", E);

    return 0;
}