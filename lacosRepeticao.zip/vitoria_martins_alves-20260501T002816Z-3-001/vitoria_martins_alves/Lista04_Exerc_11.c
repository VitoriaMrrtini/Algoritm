#include <stdio.h>

int main()
{
    int b, n, sum = 1;

    printf("Digite um número e a sua potência: ");
    scanf("%d", &b);
    scanf("%d", &n);

    if (n > 1)
    {
        if (b >= 2)
        {
            for (int i = 1; i <= n; i++)
            {
                sum *= b;
            }
        }
    }

    printf("Resultado: %d\n", sum);
    return 0;
}