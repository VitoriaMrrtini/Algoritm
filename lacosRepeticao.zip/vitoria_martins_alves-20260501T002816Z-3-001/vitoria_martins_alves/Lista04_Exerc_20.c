#include <stdio.h>

int main()
{
    int numero, super_fatorial = 1, fatorial;
    printf("Digite um valor: ");
    scanf("%d", &numero);

    for (int i = 1; i <= numero; i++)
    {

        fatorial = 1;
        
        for (int j = 1; j <= i; j++)
        {
            fatorial *= j;
        }

        super_fatorial *= fatorial;
    }

    printf("%d\n", super_fatorial);

    return 0;
}