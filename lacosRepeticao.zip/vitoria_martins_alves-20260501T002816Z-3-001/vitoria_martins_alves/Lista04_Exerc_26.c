#include <stdio.h>
#include <stdbool.h>

int main()
{
    int numero_1, numero_2, opcao, sum = 1;

    do
    {
        printf("1 - soma\n"
               "2 - subtração\n"
               "3 - multiplicação\n"
               "4 - Divisão\n"
               "5 - Fatorial\n"
               "6 - Média\n"
               "7 - Sair\n"
               "Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            printf("Digite o segundo valor: ");
            scanf("%d", &numero_2);

            printf("Seu resultado é: %d\n", numero_1 + numero_2);
            continue;
        case 2:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            printf("Digite o segundo valor: ");
            scanf("%d", &numero_2);

            printf("Seu resultado é: %d\n", numero_1 - numero_2);
            continue;
        case 3:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            printf("Digite o segundo valor: ");
            scanf("%d", &numero_2);

            printf("Seu resultado é: %d\n", numero_1 * numero_2);
            continue;
        case 4:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            printf("Digite o segundo valor: ");
            scanf("%d", &numero_2);

            if (numero_2 == 0)
            {
                printf("O segundo valor não pode ser zero, digite novamente: ");
                scanf("%d", &numero_2);
            }

            printf("Seu resultado é: %d\n", numero_1 / numero_2);
            continue;
        case 5:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            for (int i = 1; i <= numero_1; i++)
                sum *= i;

            printf("Seu resultado é: %d\n", sum);
            continue;
        case 6:
            printf("Digite o primeiro valor: ");
            scanf("%d", &numero_1);

            printf("Digite o segundo valor: ");
            scanf("%d", &numero_2);

            printf("Seu resultado é: %d\n", (numero_1 + numero_2) / 2);
            continue;
        default:
            break;
        }
    } while (opcao != 7);

    printf("Saindo da aplicação...\n");

    return 0;
}