#include <stdio.h>

int main()
{
    int numero;
    printf("Digite um valor inteiro: ");
    scanf("%d", &numero);

    for(; numero>=0; numero--)
    {
        printf("%d\n", numero);
    }
}