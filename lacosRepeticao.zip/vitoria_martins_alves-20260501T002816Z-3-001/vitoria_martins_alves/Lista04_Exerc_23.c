#include <stdio.h>
#define TAXA_A 25 / 10
#define TAXA_B 18 / 10

int main()
{
    int n;
    printf("Digite um número: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= i; j++)
        {
            printf("*");
        }
        printf("\n");
    }

    for (int i = n; i > 0; i--)
    {
        for (int j = 1; j < i; j++)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}