#include <stdio.h>

int main()
{
    int valor;

    printf("Digite um valor: ");
    scanf("%d", &valor);

    for (int i = 0; i <= 10; i++)
    {
        printf("%d x %d = %d\n", valor, i, valor*i);
    }
    

    return 0;
}