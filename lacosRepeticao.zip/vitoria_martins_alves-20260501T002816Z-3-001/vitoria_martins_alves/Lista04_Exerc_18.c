#include <stdio.h>

int main()
{
    int numero, sum = 1;
    printf("Digite um valor: ");
    scanf("%d", &numero);

    for (int i = 1; i <= numero; i++)
        sum *= i;

    printf("%d\n", sum);

    return 0;
}