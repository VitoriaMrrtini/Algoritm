#include <stdio.h>

int main()
{
    int M, N;

    printf("Digite um número: ");
    scanf("%d", &M);
    printf("Digite um número: ");
    scanf("%d", &N);

    for (; M > 0; M--)
    {   
        for (int i = N; i > 0; i--)
        {
            printf("%d ", 0);
        }
        printf("\n");
    }
    

    return 0;
}