#include <stdio.h>

int main()
{
    int numero, j = 0;

    printf("Digite um número: ");
    scanf("%d", &numero);

    for (int i = 1; i < numero; i++)
    {
        if (numero % i == 0)
        {
            j++;
        }
    }

    if (j > 2)
    {
        printf("Não é primo\n");
    }
    else
    {
        printf("É primo\n");
    }

    return 0;
}