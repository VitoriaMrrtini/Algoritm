#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));
    int tentativa, min = 1, max = 1000;
    int numero_aleatorio = (rand() % (max - min + 1)) + min;

    do
    {
        printf("Tente acertar o número aleatório: ");
        scanf("%d", &tentativa);

        if (tentativa > numero_aleatorio)
            printf("Seu chute deve ser menor\n");
        else if ((tentativa < numero_aleatorio))
            printf("Seu chuve deve ser maior\n");

    } while (tentativa != numero_aleatorio);

    printf("Vocẽ acertou o número aleatório!\n");

    return 0;
}