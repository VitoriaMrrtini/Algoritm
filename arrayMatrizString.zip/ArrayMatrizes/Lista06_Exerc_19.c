#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[100];
    char letra;
    char vogais[] = "aeiouAEIOU";

    printf("Digite uma letra: ");
    scanf(" %c", &letra);
    printf("Digite uma frase: ");
    scanf(" %[^\n]", frase);

    for (int i = 0; vogais[i] != '\0'; i++)
    {
        for (int j = 0; j < strlen(frase); j++)
        {
            if (vogais[i] == frase[j])
            {
                frase[j] = letra;
            }
        }
    }

    printf("%s\n", frase);

    return 0;
}