#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char palavra[100];
    int validador = 1;

    scanf(" %[^\n]", palavra);

    int tam = strlen(palavra);
    int j = tam - 1;

    for (int i = 0; i < strlen(palavra); i++)
    {

        if (palavra[i] != palavra[j])
        {
            validador = 0;
            break;
        }
        j--;
    }

    if (validador == 0)
    {
        printf("Não é um palíndromo\n");
    }
    else
    {
        printf("É um palíndromo\n");
    }

    return 0;
}