#include <stdio.h>
#include <stdlib.h>

#define N 3

int main()
{
    int num[N][N];
    int soma_secundaria = 0;
    int soma_primario = 0;
    int vetor_coluna[N] = {0};
    int vetor_linha[N] = {0};
    int sinal = 1;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf(" %d", &num[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i == j)
            {
                soma_primario += num[i][j];
            }
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if ((i + j) == (N - 1))
            {
                soma_secundaria += num[i][j];
            }
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            vetor_coluna[i] += num[j][i];
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            vetor_linha[i] += num[i][j];
        }
    }


    if (soma_primario != soma_secundaria)
    {
        sinal = 0;
    }
    
    for (int i = 0; i < N; i++)
    {
        if (vetor_linha[i] != soma_primario || vetor_coluna[i] != soma_primario)
        {
            sinal = 0;
            break;
        }
        
    }
    
    if (sinal == 0)
    {
        printf("Não é um quadrado mágico\n");
    }
    else
    {
        printf("É um quadrado mágico\n");
    }
    
    

    return 0;
}