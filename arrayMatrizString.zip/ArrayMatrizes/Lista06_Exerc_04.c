#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 5

int main()
{
    int num[N];
    int mult[N];
    int k;

    printf("Digite um valor K: ");
    scanf(" %d", &k);

    for (int i = 0; i < N; i++)
    {
        printf("Digite um número: ");
        scanf(" %d", &num[i]);
    }

    for (int i = 0; i < N; i++)
    {
        mult[i] = num[i] * k;
        printf(" %d ", mult[i]);
    }

    printf("\n");

    return 0;
}