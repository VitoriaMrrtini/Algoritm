#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[100];
    char caracter;
    int contador = 0;

    scanf(" %[^\n]", frase);
    scanf(" %c", &caracter);

    int tamanho = strlen(frase);

    for (int i = 0; i < tamanho; i++)
    {
        if (frase[i] == caracter)
        {
            contador++;
        }
    }

    printf("O caracter %c foi encontrado: %d\n", caracter, contador);

    return 0;
}