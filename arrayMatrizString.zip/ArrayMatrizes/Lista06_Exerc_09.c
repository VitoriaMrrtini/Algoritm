#include <stdio.h>
#include <stdlib.h>

#define N 3

int Main()
{
    int triangular = 1;
    int mat[N][N];

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i > j && mat[i][j] != 0)
            {
                triangular = 0;
                break;
            }
        }
    }

    if (triangular == 1)
    {
        printf("A matriz é triangular\n");
    }
    else
    {
        printf("A matriz não é triangular\n");
    }

    return 0;
}