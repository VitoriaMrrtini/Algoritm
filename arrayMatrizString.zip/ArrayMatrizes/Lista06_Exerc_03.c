#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define X 3
#define Y 3

int main()
{

    int num[X][Y];
    int maior = -9999;

    for (int i = 0; i < X; i++)
    {
        for (int j = 0; j < Y; j++)
        {
            scanf(" %d", &num[i][j]);
        }
    }

    for (int i = 0; i < X; i++)
    {
        for (int j = 0; j < Y; j++)
        {
            if ((i + j) == (X - 1))
            {
                if (maior < num[i][j])
                {
                    maior = num[i][j];
                }
            }
        }
    }

    printf("O maior número da matriz é %d\n", maior);

    return 0;
}