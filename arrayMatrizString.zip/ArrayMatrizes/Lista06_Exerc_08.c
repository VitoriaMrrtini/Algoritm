#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 5
#define M 3

int main()
{
    int mat[N][M];
    int maior = -9999, menor = 9999;
    int soma = 0;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            scanf(" %d", &mat[i][j]);
        }
        
    }
    

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            soma += mat[i][j];
        }
        if (maior < soma)
        {
            maior = soma;
        }
        soma = 0;
    }

    for (int j = 0; j < N; j++)
    {
        for (int i = 0; i < M; i++)
        {
            soma += mat[i][j];
        }
        if (menor > soma)
        {
            menor = soma;
        }
        
        soma = 0;
    }
    

    printf("A maior soma das linhas é %d e a menor soma das colunas é %d\n", maior, menor);

    return 0;
}