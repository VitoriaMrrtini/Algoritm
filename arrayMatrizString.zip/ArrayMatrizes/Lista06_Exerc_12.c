#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 10

int main()
{
    int mat[N][N];

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (j == i || ((j + i) == (N - 1)))
            {
                mat[i][j] = 1;
            }
            else
            {
                mat[i][j] = 0;
            }
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }

    return 0;
}