#include <stdio.h>
#include <stdlib.h>

int main()
{

    int vet1[4] = {1, 4, 10, 50};
    int vet2[6] = {2, 5, 20, 30, 40, 50};
    int vetor[10];

    int j = 0;
    int i = 0;
    int k = 0;

    while (i < 4 && j < 6)
    {
        if (vet2[i] < vet2[j])
        {
            vetor[k] = vet1[i];
            i++;
        }
        else
        {
            vetor[k] = vet2[j];
            j++;
        }
        k++;
    }
    
    while (i < 4)
    {
        vetor[k] = vet1[i];
        i++;
        k++;
    }


    while (j < 4)
    {
        vetor[k] = vet2[j];
        j++;
        k++;
    }
    
    for (int i = 0; i < 10; i++)
    {
        printf("%d ", vetor[i]);
    }
    printf("\n");

    return 0;
}