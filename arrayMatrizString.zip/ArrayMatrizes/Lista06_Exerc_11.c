#include <stdio.h>
#include <stdlib.h>

#define N 4

int main()
{
    int mat[N][N];
    int mat_tr[N][N];

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i < j)
            {
                mat_tr[i][j] = 0;
            }
            else
            {
                mat_tr[i][j] = mat[i][j];
            }
        }
    }
    
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            printf("%d ", mat_tr[i][j]);
        }
        printf("\n");
    }

    return 0;
}