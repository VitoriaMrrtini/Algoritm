#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str1[100];
    char str2[100];
    int j = 0;

    scanf(" %[^\n]", str1);

    for (int i = 0; str1[i] != '\0'; i++)
    {
        if (str1[i] != ' ')
        {
            str2[j] = str1[i];
            j++;
        }
    }

    printf("%s\n", str2);

    return 0;
}