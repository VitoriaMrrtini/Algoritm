#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase[100];
    char vogais[6] = "aeiou";
    int contador[6] = {0};

    printf("Digite uma frase: ");
    scanf(" %[^\n]", frase);

    for (int i = 0; vogais[i] != '\0'; i++)
    {
        for (int j = 0; j < strlen(frase); j++)
        {
            if (vogais[i] == frase[j])
            {
                contador[i]++;
            }
        }

        printf("%c: %d\n", vogais[i], contador[i]);
    }
    

    return 0;
}