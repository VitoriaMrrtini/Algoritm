#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define TAMANHO 10

int main()
{

    int num1[TAMANHO], num2[TAMANHO];
    float resultado, subtacao = 0.0;

    for (int i = 0; i < TAMANHO; i++)
    {
        printf("Digite o primeiro vetor: ");
        scanf(" %d", &num1[i]);
        printf("Digite o segundo vetor: ");
        scanf(" %d", &num2[i]);
    }

    for (int i = 0; i < TAMANHO; i++)
    {
        subtacao += pow(num2[i] - num1[i], 2);
    }
    
    resultado = sqrt(subtacao);

    printf(" %.2f\n", resultado);

    return 0;
}