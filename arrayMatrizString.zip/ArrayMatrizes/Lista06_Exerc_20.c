#include <stdio.h>
#include <string.h>

int main()
{
    char frase1[100];
    char frase2[100];
    char vogais[] = "aeiouAEIOU";
    int escreve = 0;

    printf("Digite uma frase: ");
    scanf(" %[^\n]", frase1);

    for (int i = 0; frase1[i] != '\0'; i++)
    {
        int vogal = 0;

        for (int k = 0; vogais[k] != '\0'; k++)
        {
            if (frase1[i] == vogais[k])
            {
                vogal = 1;
                break;
            }
        }

        if (vogal == 0)
        {
            frase2[escreve] = frase1[i];
            escreve++;
        }
    }

    frase2[escreve] = '\0';

    printf("Frase sem vogais: %s\n", frase2);

    return 0;
}