#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 3

int main()
{
    int mat[N][N];
    int soma = 0;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i < j)
            {
                soma += mat[i][j];
            }
        }
    }

    printf("%d ", soma);

    return 0;
}