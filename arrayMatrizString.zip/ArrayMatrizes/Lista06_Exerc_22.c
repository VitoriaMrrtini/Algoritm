#include <stdio.h>
#include <string.h>

int main()
{
    char str1[15];
    char str2[15];
    char str[40];
    int j = 0;

    printf("Digite o primeiro nome:");
    scanf( "%[^\n]", str1);
    printf("Digite o segundo nome:");
    scanf(" %[^\n]", str2);

    for (int i = 0; i < strlen(str1); i++)
    {
        str[j] = str1[i];
        j++;
    }
    str[j] = ' ';
    j++;
    for (int i = 0; i < strlen(str2); i++)
    {
        str[j] = str2[i];
        j++;
    }
    str[j] = '\0';
    
    printf("%s\n", str);

    return 0;
}