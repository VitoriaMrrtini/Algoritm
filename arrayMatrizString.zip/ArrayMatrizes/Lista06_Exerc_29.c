#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char str1[100]; 

    scanf("%[^\n]", str1);

    for (int i = 0; str1[i] != '\0'; i++)
    {
        if (str1[i] >= 'A' && str1[i <= 'Z'])
        {
            str1[i] = str1[i] + 32;
        }
    }

    printf("%s\n", str1);
    
    return 0;
}