#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main()
{
    char frase[100];
    char caracteres[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    scanf("%[^\n]", frase);

    for (int i = 0; caracteres[i] != '\0'; i++)
    {
        for (int j = 0; j < strlen(frase); j++)
        {
            if (frase[j] >= 'a' && frase[j] <= 'z')
            {
                frase[j] = frase[j] - 32;
            }
        }
    }
    
    printf("%s\n", frase);

    return 0;
}