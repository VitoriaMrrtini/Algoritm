#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 10

int main()
{
    int mat[N][N];

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i < j)
            {
                mat[i][j] = 2 * i + 7 * j;
            }
            else if (i == j)
            {
                mat[i][j] = 2 * (i * i) - 1;
            }
            else
            {
                mat[i][j] = 4 * pow(i, 3) + 5 * pow(j, 2) + 1;
            }
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }

    return 0;
}