#include <stdio.h>
#include <string.h>

int main()
{
    char nome[100], sexo;
    int idade;
    float altura, peso;

    printf("Qual o seu nome: ");
    scanf(" %[^\n]", nome);
    printf("Qual o seu sexo (M/F): ");
    scanf(" %c", &sexo);
    printf("Qual a sua idade, altura e peso: ");
    scanf(" %d %f %f", &idade, &altura, &peso);
    printf("%s com %d e %.2f com %.2f metros, do sexo %c tem imc igual a %.2f", nome, idade, peso, altura, sexo, (peso / (altura * altura)));

    return 0;
}