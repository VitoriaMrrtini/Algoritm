#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 3
#define M 3

int main()
{
    int mat[N][M];
    int vet[N] = {0};

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            printf("digite o valor: ");
            scanf(" %d", &mat[i][j]);
        }
    }

    for (int j = 0; j < N; j++)
    {
        for (int i = 0; i < M; i++)
        {
            vet[j] += mat[i][j];
        }
    }

    for (int i = 0; i < N; i++)
    {
        printf("%d ", vet[i]);
    }

    printf("\n");

    return 0;
}