#include <stdio.h>
#include <stdlib.h>

#define TAMANHO 10

int main(){

    int num[TAMANHO];
    int dobro[TAMANHO];

    for (int i = 0; i < TAMANHO; i++)
    {
        printf("Digite um número: ");
        scanf(" %d", &num[i]);
    }
    
    for (int i = 0; i < TAMANHO; i++)
    {
        dobro[i] = num[i] * 2;
        printf("%d ", dobro[i]);
    }
    
    printf("\n");

    return 0;
}