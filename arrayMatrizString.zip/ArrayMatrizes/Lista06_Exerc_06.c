#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 5
#define M 3

int main()
{
    int num[N][M];
    int soma;
    int linhas = 0, colunas = 0;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            printf("Digite um valor: ");
            scanf(" %d", &num[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        soma = 0;
        for (int j = 0; j < M; j++)
        {
            soma += num[i][j];
        }
        if (soma == 0)
        {
            linhas++;
        }
    }

    for (int j = 0; j < N; j++)
    {
        soma = 0;
        for (int i = 0; i < M; i++)
        {
            soma += num[i][j];
        }
        if (soma == 0)
        {
            colunas++;
        }
    }

    printf("O número de linhas nulas é %d e o numero de colunas nulas é %d", linhas, colunas);

    return 0;
}