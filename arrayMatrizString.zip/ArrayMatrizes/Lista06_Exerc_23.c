#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char palavra[100];
    char resultado[100];
    char primeira_letra;
    char adiciona[] = "ay";

    scanf(" %[^\n]", palavra);

    primeira_letra = palavra[0];

    if (primeira_letra >= 'A' && primeira_letra <= 'Z')
    {
        primeira_letra += 32;
    }

    int j = 0;

    for (int i = 0; palavra[i] < '\0'; i++)
    {
        resultado[j] = palavra[i];
        j++;
    }

    int tam = strlen(resultado);
    resultado[tam] = primeira_letra;
    resultado[tam + 1] = '\0';
    
    strcat(resultado, adiciona);

    printf("%s\n", resultado);

    return 0;
}