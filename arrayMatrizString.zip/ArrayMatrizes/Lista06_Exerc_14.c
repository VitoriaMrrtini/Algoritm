#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 3
#define M 3

int main()
{
    int mat[N][M];
    int linha_maior, posicao, maior = -9999, menor = 9999;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            if (maior < mat[i][j])
            {
                maior = mat[i][j];
                linha_maior = i;
            }
        }
    }

    for (int j = 0; j < M; j++)
    {
        if (menor > mat[linha_maior][j])
        {
            menor = mat[linha_maior][j];
            posicao = j;
        }
    }

    printf("O minimax da Matriz é %d, localizada na linha %d e na coluna %d\n", menor, linha_maior+1, posicao+1);
    
    return 0;
}