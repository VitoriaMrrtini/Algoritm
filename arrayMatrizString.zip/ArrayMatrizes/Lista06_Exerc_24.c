#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    char nome[100];
    int contador = 0;

    printf("Digite seu nome: ");
    scanf("%[^\n]", nome);

    for (int i = 0; nome[i] != '\0'; i++)
    {
        contador++;
    }
    
    printf("O nome '%s' tem %d caracteres\n", nome, contador);

    return 0;
}