#include <stdio.h>
#include <stdlib.h>

#define N 5

int main()
{
    int mat[N][N];
    int triangulo = 1;

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (i > j && mat[i][j] != 0)
            {
                triangulo = 0;
                break;
            }
        }
    }

    if (triangulo == 1)
    {
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if (i < j && mat[i][j] != 0)
                {
                    printf("Posição %d e %d\n", i, j);
                }
            }
        }
    }

    return 0;
}