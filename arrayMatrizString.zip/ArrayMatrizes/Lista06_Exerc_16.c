#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 10
#define M 3

int main()
{
    int notas[N][M], qtdeP1 = 0, qtdeP2 = 0, qtdeP3 = 0, j = 0;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < M; j++)
        {
            printf("Digite a nota do aluno %d na Prova %d: ", i + 1, j + 1);
            scanf("%d", &notas[i][j]);
        }
    }
    for (int i = 0; i < N; i++)
    {
        if (notas[i][j] < notas[i][j + 1] && notas[i][j] < notas[i][j + 2])
        {
            qtdeP1++;
        }
        else if (notas[i][j + 1] < notas[i][j] && notas[i][j + 2] < notas[i][j])
        {
            qtdeP2++;
        }
        else
        {
            qtdeP3++;
        }
    }
    printf("Piores notas na P1: %d\nP2: %d\nP3: %d", qtdeP1, qtdeP2, qtdeP3);

    return 0;
}