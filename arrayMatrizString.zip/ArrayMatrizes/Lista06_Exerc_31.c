#include <stdio.h>
#include <stdlib.h>

#define TAMANHO 100

int main()
{
    float vetor[TAMANHO];
    float vetorNormalizado[TAMANHO];

    for (int i = 0; i < TAMANHO; i++)
    {
        scanf(" %f", &vetor[i]);
    }

    float min = vetor[0];
    float max = vetor[0];

    for (int i = 0; vetor[i] < TAMANHO; i++)
    {
        if (vetor[i] > max)
        {
            max = vetor[i];
        }
        if (vetor[i] < min)
        {
            min = vetor[i];
        }
    }

    for (int i = 0; vetor[i] < TAMANHO; i++)
    {
        vetorNormalizado[i] = (vetor[i] - min / (max - min));
    }

    for (int i = 0; i < TAMANHO; i++)
    {
        printf("Vetor Normalizado: %.2f\n", vetorNormalizado[i]);
    }
    printf("\n");

    return 0;
}