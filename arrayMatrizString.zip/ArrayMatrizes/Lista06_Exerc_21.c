#include <stdio.h>
#include <string.h>

int main()
{
    char frase1[100];
    char frase2[100];

    printf("Digite a primeira frase: ");
    scanf(" %[^\n]", frase1);
    printf("Digite a segunda frase: ");
    scanf(" %[^\n]", frase2);

    int i = 0;

    while (frase1[i] == frase2[i] && frase1[i] != '\0')
    {
        i++;
    }

    if (frase1[i] == '\0' && frase2[i] == '\0')
    {
        printf("As strings são iguais\n");
    }
    else
    {
        printf("As strings são diferentes\n");
    }

    return 0;
}